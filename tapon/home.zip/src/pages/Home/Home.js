import Slider from "../../components/common/slider/Slider";

export default function Home() {
  return (
    <>
      <Slider />
      {/* Add more sections here */}
    </>
  );
}
