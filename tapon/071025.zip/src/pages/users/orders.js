import React from "react";

function orders() {
  return <div>orders</div>;
}

export default orders;
