import React from "react";

function ProductPage() {
  return <div>ProductPage</div>;
}

export default ProductPage;
